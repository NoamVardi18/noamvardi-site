MORNING AGENTS — Free Templates
From: sharpendaily.co/articles/two-ai-agents-that-run-my-morning

-----------------------------------------------------------------
WHAT'S INSIDE
-----------------------------------------------------------------

1. mb-context.md         → Place in: ~/.claude/agents/mb-context.md
2. mb-finance.md         → Place in: ~/.claude/agents/mb-finance.md
3. morning-briefing-skill.md → Place in: ~/.claude/skills/morning-briefing/SKILL.md

-----------------------------------------------------------------
THESE ARE TEMPLATES — SWAP YOUR OWN DETAILS
-----------------------------------------------------------------

mb-context.md:
  - Vault path: C:\Users\vardi\Obsidian  →  your Obsidian vault path
  - Obsidian note structure: Daily\<date>.md, Daily\<week>.md (customize to your schema)
  - Gmail access: uses claude.ai web connector (CLI gap — see agent notes)

mb-finance.md:
  - Supabase project IDs: replace with your own
  - Telegram chat_id: replace with your Telegram user ID
  - Holdings table schema: adapt to your own portfolio DB

morning-briefing-skill.md:
  - References mb-context + mb-finance by name — just ensure both agent files are in place

-----------------------------------------------------------------
HOW IT WORKS
-----------------------------------------------------------------

Run: say "good morning" to Claude Code (CLI) in your EA project.
The morning-briefing skill fires two parallel agents:
  - mb-context: reads your vault + calendar + Garmin → 5-line picture
  - mb-finance: prices your holdings → Telegram ping in <90s
Both run in their own context windows. Main thread gets ~10 lines total.

-----------------------------------------------------------------
REQUIREMENTS
-----------------------------------------------------------------
- Claude Code (claude.ai/code)
- Google Calendar MCP (or gcal.js fallback)
- Garmin MCP (github.com/Rytisgit/garmin-mcp) — optional, skip if not using Garmin
- Supabase — for mb-finance (or adapt to your own data source)
- Telegram Bot — for the phone ping (optional, remove from mb-finance if not needed)
- Obsidian vault with daily notes — for mb-context

More at: sharpendaily.co
