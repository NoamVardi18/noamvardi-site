---
name: morning-briefing
description: Noam's morning planning ritual. When he opens the day ("good morning", "morning", "בוקר טוב", "let's plan the day", "what's on today", or his first message of a new day), git-pull the vault, gather yesterday's unfinished items + this week's goals + today's calendar + flagged inbox, then run a SCHEDULING PASS — his night-written plan has no times, so assign each item a time slot (propose, he confirms) and create the Google Calendar events. Surface weekly goals so he can pull any into today, suggest extra items, then write today's Obsidian daily note with the timed task list. On-demand / message-triggered — the reliable path vs the best-effort cron. Reads the vault (authorized standing for this ritual).
---

# Morning Briefing

Noam's "start the day" ritual. He writes in the morning → this gathers context, co-plans the day, and lands it in today's daily note. Triggered by his message (always works) — not dependent on a cron firing.

## Standing authorization

Noam asked for this ritual explicitly → reading **yesterday's + today's daily notes** and writing **today's** is pre-approved (overrides CLAUDE.md §3 "ask first" *for these specific daily-note files only*). Do NOT wander the rest of the vault without asking.

## Step 0 — Gather via two subagents, IN PARALLEL

Don't gather inline — it floods this context with verbose vault/calendar/mail/SQL output and is slow. Instead fire **both** dedicated subagents in ONE message (two `Agent` calls in the same turn so they run concurrently). Each absorbs its own bulk and returns a tiny structured result.

1. **`mb-context`** (subagent_type: `mb-context`, mode **gather**) — syncs the vault, folds new trade notes, reads yesterday/today/this-week's daily notes, lists today's calendar, pulls flagged Gmail, and pulls **Garmin morning health** (readiness, last night's sleep, body battery, HRV, resting HR) + reads `fitness-profile.md`. Returns `{carryovers, weekly_goals, calendar, flagged_mail, journal_intent, today_note_state, health, health_flag}`. Prompt it: `"mode: gather. Today is <YYYY-MM-DD>."`
2. **`mb-finance`** (subagent_type: `mb-finance`, mode **brief**) — LIGHT & fast: prices Noam's live holdings, builds the portfolio summary, and **sends it to his phone via Telegram** (the live `agent_bridge` bridge). NO site dashboard, NO HTML render, NO Tavily — target <90s. Returns `{mode, total, day_pct, movers, ips_flag, headlines, trade_intel, ping_sent}` (`trade_intel` = the "בוקר טוב" market-intel block: recent TV ratings + active theses for held/watched tickers, ≤4 short strings). Prompt it: `"mode: brief. Today is <YYYY-MM-DD>."`

Both are defined in `~/.claude/agents/`. If a subagent returns an error or null, say so in one line and continue with whatever the other returned — don't block the briefing. **The site dashboard + the bot's 13:00 cited-news row are NOT this skill's job** — they're owned by the 08:10 `FA Dashboard Daily` Windows task (and the manual `fa-dashboard` skill / `mb-finance` full mode). Morning brief just prices + pings the phone.

Merge the two results → present the picture (Flow below). This replaces what used to be ~15 inline tool calls with 2 parallel subagent calls.

## Flow

1. **Present the picture** — tight, scannable:
   ```
   ## Good morning — <date>

   **Recovery:** <from `health`: readiness · sleep · body battery · HRV · RHR — or "Garmin unavailable">
   **⚡ Today's body call:** <`health_flag` — the one recovery-based suggestion (go lighter / good day to push); omit the line if empty>
   **Carried from yesterday:** <his night-written plan items / unfinished tasks, untimed — or "clean slate">
   **This week's goals:** <unchecked weekly goals — or "none set">
   **Today's calendar:** <events, or "nothing scheduled">
   **Flagged mail:** <N action items, titles — or "none">
   **Market brief:** <from mb-finance: `total` · `day_pct` · `movers` · `ips_flag` if not "none"> · <`headlines`>. <if `ping_sent`: "Sent to your phone." · else: "Phone ping failed — " + note>
   **Trading intel:** <`trade_intel` lines — TV ratings + theses for your tickers; omit this line entirely if `trade_intel` is empty>

   ```
   When you propose the schedule (step 2), let `health_flag` shape it — low recovery → suggest a lighter day / move the hard workout; high readiness → good day for the demanding block.
2. **Scheduling pass — the core of this ritual.** Noam writes tomorrow's plan at night *without times*. The morning job assigns the times and puts them on the calendar:
   - Take each carry-over / night-plan item and **propose a concrete time slot**, anchored to his known day-shape (military/field commitments, workout, AI-work-in-the-evening — read from the journal, don't hardcode). Respect existing calendar events (no collisions).
   - Add **suggestions of your own**, clearly labeled (an ordering, a focus block, an obvious task he forgot). Offer to pull in a **weekly goal** if one fits the day.
   - Present it all as ONE numbered proposal and ask him to confirm/adjust in a single reply — e.g. "times look right? move anything? add a weekly goal?". One round, not item-by-item interrogation.
3. **Commit the plan — ONE handoff to `mb-context` commit mode.** Once Noam confirms, hand the full confirmed plan to **`mb-context`** (`subagent_type: mb-context`, prompt `"mode: commit"` + the timed list `[{time,title}]` + carry-over/deferred marks + `today_note_state` from the gather result). It does ALL the writes in its own context so this thread never holds the calendar/vault/git bulk: collision-safe `git pull --rebase` → create one Calendar event per timed item (`Asia/Jerusalem`) → write/update today's `## משימות להיום` (never clobbering `## Notes`) → commit + push. It returns `{created, note_written, pushed, notes}` — relay that in one line. Only after Noam's confirmation; never auto-commit silently. If it returns `pushed:false` (merge conflict) or `note_written:false` (rich journal — needs confirm), surface that to Noam and resolve before retrying.

## End-of-day companion → `evening-close`

The night half of this loop is its own skill: **`evening-close`** (mirror of this one). It checks off what got done, ticks the weekly tracker, guides the journal entry, and writes tomorrow's tasks **untimed** — which is exactly the night-written plan this morning ritual expects to schedule. Both share the `mb-context` agent. When Noam winds down ("wrap up", "סיכום יום"), that's evening-close, not this skill.

## Rules

- **Never invent tasks.** Carry-overs come from real unchecked items; new tasks come from Noam's words. Suggestions are labeled as suggestions.
- **One round, not many.** Propose the full schedule in one shot; he adjusts in one reply. Efficiency-first (CLAUDE.md §6).
- Daily-note headers in English (matches his `## Notes` pattern); body content stays in his language (Hebrew).
- **Calendar writes are allowed here** — but only after Noam confirms the proposed times. Never auto-create events silently, never guess a time he didn't approve. Inbox stays read-only. No drafting/sending mail.
- Weekly goals are surfaced read-only — only pulled into today (or checked off) if Noam says so.
- Don't read beyond the daily notes + current weekly note in the vault without asking.

## Why message-triggered (not cron)

Decided 2026-06-14: CronCreate jobs in this environment are session-only and auto-expire in 7 days — too fragile for a daily ritual. So NO cron. This skill fires whenever Noam opens the day with a message — always works, zero infra. If he ever wants a true cold-start scheduler, the option is a Windows Task Scheduler job launching Claude headless (parked, not built).
