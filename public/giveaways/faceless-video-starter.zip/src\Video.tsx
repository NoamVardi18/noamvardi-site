import { AbsoluteFill, useCurrentFrame, useVideoConfig, staticFile } from "remotion";
import { useEffect, useState } from "react";

type Word = { word: string; start: number; end: number };

// Minimal caption beat: shows the current word(s), timed off words.json.
// This is the skeleton — ask Claude Code to add image beats, b-roll, motion.
export const Video: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps; // current time in seconds
  const [words, setWords] = useState<Word[]>([]);

  useEffect(() => {
    fetch(staticFile("words.json"))
      .then((r) => r.json())
      .then(setWords)
      .catch(() => setWords([]));
  }, []);

  // the word being spoken right now
  const active = words.find((w) => t >= w.start && t < w.end);

  return (
    <AbsoluteFill
      style={{
        background: "#1a1a1a",
        justifyContent: "center",
        alignItems: "center",
        fontFamily: "Inter, system-ui, sans-serif",
      }}
    >
      <div
        style={{
          color: "#fff",
          fontSize: 96,
          fontWeight: 800,
          textAlign: "center",
          padding: 80,
          textShadow: "0 4px 24px rgba(0,0,0,0.6)",
        }}
      >
        {active?.word ?? ""}
      </div>
    </AbsoluteFill>
  );
};
