# Faceless Video Starter Pack

A working skeleton of the system that produces every SharpenDaily video — script in, finished MP4 out. This is **not** magic. It's four small pieces that Claude Code wires together. Here's exactly how it works and how to build your own.

## The honest version

The hook is true: the first working skeleton came from a few plain-English sentences to Claude Code. But the system you'd actually ship is the result of **iteration** — Claude writes a piece, runs it, sees what breaks, fixes it, and you refine over a handful of passes. The 3 sentences start it. The loop finishes it.

What you get here is that skeleton, cleaned up, so you start from a working base instead of a blank folder.

## The real stack

| Layer | Tool | Job |
|-------|------|-----|
| Orchestrator | **Claude Code** | Reads your files, writes the pieces, runs + fixes them in a loop |
| Runtime | **Node.js** | Runs every script below |
| Voice | **ElevenLabs API** | Turns a `.txt` script into a voiceover `.mp3` (with word timings) |
| Visuals + render | **Remotion** | React-based video — your beats are React components, rendered to frames |
| Stitch + encode | **ffmpeg** | Muxes the voiceover + rendered video into the final MP4 |

That's the whole thing. No proprietary anything — every layer is a public tool.

## How the pieces connect

```
script.txt
   │
   ▼
tts.js ──(ElevenLabs)──► vo.mp3 + words.json   (voiceover + per-word timing)
   │
   ▼
Remotion comp ──(reads words.json)──► renders timed visual beats ──► video.mp4 (no audio)
   │
   ▼
render.sh ──(ffmpeg)──► mux vo.mp3 + video.mp4 ──► final.mp4
```

The key idea: **`words.json` (word-level timestamps from ElevenLabs) is the clock.** Every visual beat is timed to a word, so the visuals always land on the voiceover. That's what makes it look produced instead of slapped together.

## What's in this pack

- `PROMPTS.md` — the exact prompts to give Claude Code (the kickoff + the refinement loop)
- `SETUP.md` — install + run, step by step
- `tts.js` — minimal ElevenLabs voiceover script (script.txt → vo.mp3 + words.json)
- `src/Root.tsx`, `src/Video.tsx` — minimal Remotion composition that reads `words.json`
- `render.sh` — render Remotion + mux with ffmpeg
- `package.json`, `.env.example`

Start with `SETUP.md`.
