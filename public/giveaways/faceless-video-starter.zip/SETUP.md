# Setup

You need: **Node.js 18+**, **ffmpeg** on your PATH, and an **ElevenLabs API key** (free tier works).

## 1. Install

```
npm install
```

## 2. Add your key

Copy `.env.example` to `.env` and paste your ElevenLabs key:

```
ELEVENLABS_API_KEY=your_key_here
ELEVENLABS_VOICE_ID=your_voice_id   # optional; defaults to a stock voice
```

Get a key at elevenlabs.io → Profile → API Keys. Pick a voice ID at elevenlabs.io/app/voice-library.

## 3. Write a script

Put your voiceover text in `script.txt`. One short video's worth — 40 to 60 seconds of speech is plenty to test.

## 4. Run it

```
node tts.js --file script.txt --out vo.mp3      # → vo.mp3 + words.json
bash render.sh                                   # → out/final.mp4
```

`render.sh` renders the Remotion composition (which reads `words.json` to time the captions) and muxes it with `vo.mp3` using ffmpeg.

## 5. Now hand it to Claude Code

This skeleton only does captions timed to the voice. The fun starts when you ask Claude Code to extend it — add image beats, b-roll, music, SFX, chapters. Use the prompts in `PROMPTS.md`.

That's the point: you're not building from zero. You're handing Claude Code a working base and describing what to add next.

## Troubleshooting

- **`ffmpeg: command not found`** — install ffmpeg and reopen your terminal.
- **401 from ElevenLabs** — check `.env`; the key must be on the machine running `tts.js`.
- **Remotion render is slow the first time** — it downloads a headless browser once, then caches it.
