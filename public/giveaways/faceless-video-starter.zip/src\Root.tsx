import { Composition, getInputProps } from "remotion";
import { Video } from "./Video";

// Duration is derived from the voiceover length. render.sh passes --props with
// durationInFrames so the video is exactly as long as the audio.
export const RemotionRoot: React.FC = () => {
  const props = getInputProps() as { durationInFrames?: number };
  const duration = props.durationInFrames ?? 30 * 30; // fallback 30s @ 30fps

  return (
    <Composition
      id="Video"
      component={Video}
      durationInFrames={duration}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
