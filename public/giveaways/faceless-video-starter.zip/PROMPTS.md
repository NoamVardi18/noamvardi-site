# The exact prompts

These are the real prompts that built the system. Give them to Claude Code (run `claude` inside your project folder).

## 1. The kickoff (the "3 sentences")

```
I have an existing project here. I want to turn a voiceover script into a
finished video automatically.

Build me a complete video skill — text-to-speech, a visual/b-roll engine,
music + SFX timing, and a rendering pipeline — all connected so one command
takes a script.txt and produces a final MP4.

Use Node.js, ElevenLabs for the voiceover, Remotion for the visuals, and
ffmpeg to stitch it together. Read what's already in the folder first.
```

The third sentence matters most. Naming the **actual tools** (ElevenLabs, Remotion, ffmpeg) is the difference between a vague toy and the real system. "Build me a video tool" gets you nothing; this gets you a real architecture.

## 2. The refinement loop (run these as it builds)

You don't get a finished system from one prompt. You steer it. These are the follow-ups that did the real work:

```
The voiceover works, but the visuals aren't timed to it. Read the word
timestamps from ElevenLabs and drive every visual beat off them, so each
beat lands on the right word.
```

```
Each render is one giant file and it crashes on long videos. Split it into
~60-90s chapters, render each separately, then concat with ffmpeg.
```

```
Run the whole thing end to end on a sample script.txt. When something
breaks, fix it and run it again — don't stop until it produces a final.mp4.
```

## 3. The rule that makes Claude Code actually work

Be specific about **inputs, outputs, and where files live.** Don't explain *how* to build it — describe what success looks like.

```
Wrong:  "Make the videos look better"
Right:  "Every visual beat must start on a word boundary from words.json,
         hold no longer than 4 seconds, and never show the same card twice
         in a row. Output 1080x1920 at 30fps to /out/final.mp4."
```

Treat it like a junior developer you can hand a clear spec to — not a search engine, not a chatbot.
