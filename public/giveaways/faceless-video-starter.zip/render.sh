#!/usr/bin/env bash
# render.sh — render the Remotion comp, then mux the voiceover in with ffmpeg.
# Needs: vo.mp3 + words.json (run tts.js first), node, ffmpeg.
set -e

mkdir -p out public

# words.json must be reachable by Remotion as a static file.
cp -f words.json public/words.json

# Length of the video = length of the voiceover (so visuals never run dry).
DUR_SEC=$(ffprobe -v error -show_entries format=duration -of csv=p=0 vo.mp3)
FPS=30
DUR_FRAMES=$(python -c "import math,sys; print(math.ceil(float('$DUR_SEC')*$FPS))" 2>/dev/null \
  || node -e "console.log(Math.ceil(parseFloat('$DUR_SEC')*$FPS))")

echo "voiceover ${DUR_SEC}s -> ${DUR_FRAMES} frames"

# 1. Render the visuals (no audio yet).
npx remotion render src/index.ts Video out/video.mp4 \
  --props="{\"durationInFrames\": ${DUR_FRAMES}}"

# 2. Mux voiceover + video into the final.
ffmpeg -y -i out/video.mp4 -i vo.mp3 \
  -c:v copy -c:a aac -shortest out/final.mp4

echo "DONE -> out/final.mp4"
