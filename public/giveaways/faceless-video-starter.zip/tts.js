// tts.js — minimal ElevenLabs voiceover for the starter pack.
// script.txt -> vo.mp3 (audio) + words.json (per-word timing that drives the visuals).
//
//   node tts.js --file script.txt --out vo.mp3
//
// Env: ELEVENLABS_API_KEY (required), ELEVENLABS_VOICE_ID (optional).
// This is a skeleton. Hand it to Claude Code to extend (SSML, multi-voice, retries).

import fs from "node:fs";

const KEY = process.env.ELEVENLABS_API_KEY;
const VOICE = process.env.ELEVENLABS_VOICE_ID || "21m00Tcm4TlvDq8ikWAM"; // stock "Rachel"
const MODEL = "eleven_multilingual_v2";

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : fallback;
}

async function main() {
  if (!KEY) throw new Error("ELEVENLABS_API_KEY not set (copy .env.example -> .env).");

  const file = arg("file", "script.txt");
  const out = arg("out", "vo.mp3");
  const text = fs.readFileSync(file, "utf8").trim();
  if (!text) throw new Error(`${file} is empty.`);

  // with-timestamps endpoint returns base64 audio + per-character alignment.
  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${VOICE}/with-timestamps`,
    {
      method: "POST",
      headers: { "xi-api-key": KEY, "Content-Type": "application/json" },
      body: JSON.stringify({ text, model_id: MODEL }),
    }
  );
  if (!res.ok) throw new Error(`ElevenLabs ${res.status}: ${await res.text()}`);
  const data = await res.json();

  fs.writeFileSync(out, Buffer.from(data.audio_base64, "base64"));

  // Group character-level alignment into [{ word, start, end }].
  const a = data.alignment || data.normalized_alignment;
  const words = [];
  if (a) {
    let cur = "";
    let start = null;
    a.characters.forEach((ch, i) => {
      const t = a.character_start_times_seconds[i];
      if (ch === " ") {
        if (cur) words.push({ word: cur, start, end: t });
        cur = "";
        start = null;
      } else {
        if (start === null) start = t;
        cur += ch;
      }
    });
    if (cur) words.push({ word: cur, start, end: a.character_end_times_seconds.at(-1) });
  }
  fs.writeFileSync("words.json", JSON.stringify(words, null, 2));

  console.log(`OK -> ${out} (${(Buffer.from(data.audio_base64, "base64").length / 1024).toFixed(0)} KB), ${words.length} words -> words.json`);
}

main().catch((e) => {
  console.error(`FAILED: ${e.message}`);
  process.exit(1);
});
